import type { NextConfig } from "next";


const nextConfig: NextConfig = {

//  eslint: {
//     // ✅ Do not run ESLint on builds
//     ignoreDuringBuilds: true,
//   },
  /* config options here */
  
};

export default nextConfig;
// pnpm add next@latest react@latest react-dom@latest
